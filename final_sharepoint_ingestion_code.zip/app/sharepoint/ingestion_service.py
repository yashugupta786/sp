import uuid
from datetime import datetime
from app.model.document_schema import DocumentModel, StepModel, SharePointInfoModel
from pymongo.errors import PyMongoError


class SharePointIngestionService:
    """
    Service to process and ingest SharePoint folder files into MongoDB.
    """

    def __init__(self, db, site_url: str):
        self.db = db
        self.site_url = site_url
        self.doc_collection = db["run_documents"]
        self.meta_collection = db["run_management"]

    async def ingest(self, folder, sp_client, tenant_id: str, engagement_id: str, year: str, quarter: str):
        """
        Ingests all files recursively from the given folder path and updates MongoDB.
        """
        try:
            self.ctx = sp_client.get_context()
            await self.ctx.load(folder.expand(["Folders"]))
            self.ctx.execute_query()

            run_doc = await self.meta_collection.find_one({"tenant_id": tenant_id, "engagement_id": engagement_id})
            run_id = run_doc.get("run_id") if run_doc else f"RUN{str(await self.meta_collection.count_documents({}) + 1).zfill(3)}"

            if not run_doc:
                await self.meta_collection.insert_one({
                    "run_id": run_id,
                    "tenant_id": tenant_id,
                    "engagement_id": engagement_id,
                    "metadata": []
                })

            for industry_folder in folder.folders:
                industry = industry_folder.properties["Name"]
                await self.ctx.load(industry_folder.expand(["Folders"]))
                self.ctx.execute_query()

                for obligor_folder in industry_folder.folders:
                    obligor = obligor_folder.properties["Name"]
                    doc_run_id = f"{industry}_{quarter}_{year}_{obligor.replace(' ', '_')}"
                    await self.ctx.load(obligor_folder.expand(["Folders", "Files"]))
                    self.ctx.execute_query()

                    # Existing base64s from DB for deduplication
                    existing_docs = await self.doc_collection.find({"doc_run_id": doc_run_id}).to_list(length=None)
                    existing_base64s = set(doc["base64"] for doc in existing_docs)
                    files = await sp_client.fetch_all_files(obligor_folder)

                    inserted_docs = []
                    for file_obj in files:
                        base64_str = sp_client.get_base64_content(file_obj)
                        if not base64_str or base64_str in existing_base64s:
                            continue

                        doc_model = DocumentModel(
                            doc_run_id=doc_run_id,
                            run_id=run_id,
                            tenant_id=tenant_id,
                            engagement_id=engagement_id,
                            year=int(year),
                            quarter=quarter,
                            industry_type=industry,
                            obligor_name=obligor,
                            doc_id=str(uuid.uuid4()),
                            original_filename=file_obj.properties["Name"],
                            renamed_filename="",
                            base64=base64_str,
                            sharepoint_info=SharePointInfoModel(
                                relative_path=file_obj.properties["ServerRelativeUrl"],
                                library_name="Documents",
                                site_url=self.site_url
                            ),
                            steps=[StepModel(
                                step_name="sharepoint_ingestion",
                                result="SUCCESS",
                                timestamp=datetime.utcnow().isoformat()
                            )]
                        )
                        inserted_docs.append(doc_model.dict())

                    if inserted_docs:
                        await self.doc_collection.insert_many(inserted_docs)

                        # Update run_management
                        await self._update_metadata(run_id, year, quarter, industry, obligor, doc_run_id)

            return {"status": "success", "message": "Ingestion complete."}

        except Exception as e:
            return {"status": "error", "message": str(e)}

    async def _update_metadata(self, run_id, year, quarter, industry, obligor, doc_run_id):
        """
        Updates the run_management metadata document intelligently.
        """
        try:
            run_doc = await self.meta_collection.find_one({"run_id": run_id})
            metadata = run_doc.get("metadata", [])
            found = False

            for meta in metadata:
                if meta["year"] == int(year) and meta["quarter"] == quarter:
                    for ind in meta["industries"]:
                        if ind["industry"] == industry:
                            if not any(o["obligor_name"] == obligor for o in ind["obligors"]):
                                ind["obligors"].append({"obligor_name": obligor, "doc_run_id": doc_run_id})
                            found = True
                            break
                    else:
                        meta["industries"].append({
                            "industry": industry,
                            "obligors": [{"obligor_name": obligor, "doc_run_id": doc_run_id}]
                        })
                        found = True
                    break

            if not found:
                metadata.append({
                    "year": int(year),
                    "quarter": quarter,
                    "industries": [{
                        "industry": industry,
                        "obligors": [{"obligor_name": obligor, "doc_run_id": doc_run_id}]
                    }]
                })

            await self.meta_collection.update_one(
                {"run_id": run_id},
                {"$set": {"metadata": metadata}}
            )

        except PyMongoError as e:
            print(f"[ERROR] MongoDB metadata update failed: {e}")
