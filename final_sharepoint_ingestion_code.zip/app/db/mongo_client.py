import yaml
from motor.motor_asyncio import AsyncIOMotorClient


class MongoDBClient:
    """
    Initializes an async MongoDB client from a YAML settings file.
    """
    def __init__(self, config_path: str = "app/config/settings.yaml"):
        with open(config_path, "r") as f:
            config = yaml.safe_load(f)
        self.mongo_uri = config["mongo_uri"]
        self.db_name = config["database"]

    def get_database(self):
        """
        Returns the database instance from AsyncIOMotorClient.
        """
        client = AsyncIOMotorClient(self.mongo_uri)
        return client[self.db_name]
