import uuid
from datetime import datetime
from app.models.document_model import DocumentModel, StepModel, SharePointInfoModel

class SharePointIngestionService:
    """
    Service class to ingest SharePoint folder content and handle MongoDB interactions.
    """

    def __init__(self, db, config):
        self.db = db
        self.site_url = config["site_url"]

    async def ingest(self, folder, sp_client, tenant_id, engagement_id, year, quarter):
        try:
            result = {"uploaded": [], "skipped": []}
            run_id = await self.ensure_run_id(tenant_id, engagement_id)
            ctx = sp_client.ctx
            ctx.load(folder.expand(["Folders"]))
            ctx.execute_query()

            for industry_folder in folder.folders:
                industry = industry_folder.properties["Name"]
                ctx.load(industry_folder.expand(["Folders"]))
                ctx.execute_query()

                for obligor_folder in industry_folder.folders:
                    obligor = obligor_folder.properties["Name"]
                    doc_run_id = f"{industry}_{quarter}_{year}_{obligor.replace(' ', '_')}"
                    ctx.load(obligor_folder.expand(["Folders", "Files"]))
                    ctx.execute_query()

                    files = await sp_client.fetch_all_files(obligor_folder)
                    existing_base64s = await self.fetch_existing_base64s(doc_run_id)
                    seen = set()

                    for file_obj in files:
                        base64_str = sp_client.get_base64_content(file_obj)
                        if not base64_str or base64_str in seen or base64_str in existing_base64s:
                            result["skipped"].append(file_obj.properties["Name"])
                            continue

                        seen.add(base64_str)
                        document = DocumentModel(
                            doc_run_id=doc_run_id,
                            run_id=run_id,
                            tenant_id=tenant_id,
                            engagement_id=engagement_id,
                            year=int(year),
                            quarter=quarter,
                            industry_type=industry,
                            obligor_name=obligor,
                            doc_id=str(uuid.uuid4()),
                            original_filename=file_obj.properties["Name"],
                            base64=base64_str,
                            sharepoint_info=SharePointInfoModel(
                                relative_path=file_obj.properties["ServerRelativeUrl"],
                                library_name="Documents",
                                site_url=self.site_url,
                            ),
                            steps=[
                                StepModel(
                                    step_name="sharepoint_ingestion",
                                    result="SUCCESS",
                                    timestamp=datetime.utcnow().isoformat()
                                )
                            ]
                        )
                        await self.db["run_documents"].insert_one(document.dict())
                        result["uploaded"].append(file_obj.properties["Name"])
            return {"status": "success", "summary": result}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    async def ensure_run_id(self, tenant_id, engagement_id):
        doc = await self.db["run_management"].find_one({"tenant_id": tenant_id, "engagement_id": engagement_id})
        if doc:
            return doc["run_id"]
        run_id = f"RUN{str(await self.db['run_management'].count_documents({}) + 1).zfill(3)}"
        await self.db["run_management"].insert_one({
            "tenant_id": tenant_id,
            "engagement_id": engagement_id,
            "run_id": run_id,
            "metadata": []
        })
        return run_id

    async def fetch_existing_base64s(self, doc_run_id):
        cursor = self.db["run_documents"].find({"doc_run_id": doc_run_id}, {"base64": 1})
        return set(doc["base64"] async for doc in cursor)
