from typing import Optional, List
from pydantic import BaseModel

class StatusModel(BaseModel):
    text_extraction: Optional[str] = ""
    vector_indexing: Optional[str] = ""

class SharePointInfoModel(BaseModel):
    relative_path: str
    library_name: str
    site_url: str

class StepModel(BaseModel):
    step_name: str
    result: str
    timestamp: str

class DocumentModel(BaseModel):
    doc_run_id: str
    run_id: str
    tenant_id: str
    engagement_id: str
    year: int
    quarter: str
    industry_type: str
    obligor_name: str
    doc_id: str
    original_filename: str
    renamed_filename: str = ""
    base64: str
    file_hash: str = "hash_placeholder"
    status: StatusModel = StatusModel()
    blob_path: str = ""
    sas_url: str = ""
    sharepoint_info: SharePointInfoModel
    steps: List[StepModel]
