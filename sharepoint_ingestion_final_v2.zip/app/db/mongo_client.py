import yaml
from motor.motor_asyncio import AsyncIOMotorClient

class MongoDBClient:
    """
    MongoDB async client to interact with database using Motor.
    """

    def __init__(self, config_path="app/config/settings.yaml"):
        with open(config_path, "r") as f:
            config = yaml.safe_load(f)
        self.mongo_uri = config["mongo_uri"]
        self.db_name = config["database"]

    def get_database(self):
        return AsyncIOMotorClient(self.mongo_uri)[self.db_name]
