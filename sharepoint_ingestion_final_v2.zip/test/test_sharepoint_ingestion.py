import asyncio
import yaml
from app.db.mongo_client import MongoDBClient
from app.services.ingestion_service import SharePointIngestionService
from app.sharepoint.sharepoint_client import SharePointClient

async def test_ingestion():
    with open("app/config/settings.yaml", "r") as f:
        config = yaml.safe_load(f)

    db = MongoDBClient().get_database()
    site_url = input("Enter SharePoint site URL: ").strip()
    folder_path = input("Enter SharePoint folder path: ").strip()
    tenant_id = input("Enter tenant ID: ").strip()
    engagement_id = input("Enter engagement ID: ").strip()

    sp_client = SharePointClient(site_url, config["client_id"], config["client_secret"])
    processor = SharePointIngestionService(db, {"site_url": site_url})

    folder_name = folder_path.strip("/").split("/")[-1]
    year, quarter = sp_client.extract_year_quarter(folder_name)
    if not year or not quarter:
        print("[ERROR] Failed to parse quarter and year")
        return

    folder = sp_client.get_folder(folder_path)
    result = await processor.ingest(folder, sp_client, tenant_id, engagement_id, year, quarter)
    print(result)

if __name__ == "__main__":
    asyncio.run(test_ingestion())
