"""
Test script for SharePoint ingestion service.
"""

import asyncio
import yaml
from app.db.mongo_client import MongoDBClient
from app.sharepoint.client import SharePointClient
from app.sharepoint.ingestion_service import SharePointIngestionService


async def test_ingestion():
    with open("app/config/settings.yaml", "r") as f:
        config = yaml.safe_load(f)

    db = MongoDBClient().get_database()

    site_url = input("Enter SharePoint site URL: ").strip()
    folder_path = input("Enter SharePoint folder path: ").strip()
    tenant_id = input("Enter tenant ID: ").strip()
    engagement_id = input("Enter engagement ID: ").strip()

    sp = SharePointClient(site_url, config["client_id"], config["client_secret"])
    folder_name = folder_path.strip("/").split("/")[-1]
    year, quarter = sp.extract_year_quarter(folder_name)

    if not year or not quarter:
        print("[ERROR] Could not parse quarter/year")
        return

    folder = sp.get_folder(folder_path)
    service = SharePointIngestionService(db, config)
    result = await service.ingest(folder, sp, tenant_id, engagement_id, year, quarter)
    print(result)


if __name__ == "__main__":
    asyncio.run(test_ingestion())