"""
Core SharePoint ingestion service.
"""

import uuid
from datetime import datetime
from app.model.document_schema import DocumentModel, SharePointInfoModel, StepModel
from bson import ObjectId


class SharePointIngestionService:
    def __init__(self, db, config):
        self.db = db
        self.config = config
        self.run_mgmt = db["run_management"]
        self.run_docs = db["run_documents"]

    async def ingest(self, folder, sp_client, tenant_id, engagement_id, year, quarter):
        try:
            await self.db.client.admin.command("ping")
        except Exception:
            return {"status": "error", "message": "Mongo connection error"}

        run = await self.run_mgmt.find_one({"tenant_id": tenant_id, "engagement_id": engagement_id})
        if not run:
            run_id = f"RUN{str(await self.run_mgmt.estimated_document_count() + 1).zfill(3)}"
            run = {
                "run_id": run_id,
                "tenant_id": tenant_id,
                "engagement_id": engagement_id,
                "metadata": []
            }
            await self.run_mgmt.insert_one(run)
        else:
            run_id = run["run_id"]

        ctx = sp_client.ctx
        ctx.load(folder.expand(["Folders"]))
        ctx.execute_query()

        for industry_folder in folder.folders:
            industry = industry_folder.properties["Name"]
            ctx.load(industry_folder.expand(["Folders"]))
            ctx.execute_query()

            for obligor_folder in industry_folder.folders:
                obligor = obligor_folder.properties["Name"]
                doc_run_id = f"{industry}_{quarter}_{year}_{obligor.replace(' ', '_')}"
                ctx.load(obligor_folder.expand(["Folders", "Files"]))
                ctx.execute_query()

                existing_docs = await self.run_docs.find({"doc_run_id": doc_run_id}).to_list(length=None)
                existing_base64 = set(doc["base64"] for doc in existing_docs)

                all_files = list(obligor_folder.files)
                new_docs = []
                for file_obj in all_files:
                    b64 = sp_client.get_base64_content(file_obj)
                    if not b64 or b64 in existing_base64:
                        continue
                    doc = DocumentModel(
                        doc_run_id=doc_run_id,
                        run_id=run_id,
                        tenant_id=tenant_id,
                        engagement_id=engagement_id,
                        year=int(year),
                        quarter=quarter,
                        industry_type=industry,
                        obligor_name=obligor,
                        doc_id=str(uuid.uuid4()),
                        original_filename=file_obj.properties["Name"],
                        base64=b64,
                        sharepoint_info=SharePointInfoModel(
                            relative_path=file_obj.properties["ServerRelativeUrl"],
                            library_name="Documents",
                            site_url=sp_client.site_url
                        ),
                        steps=[StepModel(
                            step_name="sharepoint_ingestion",
                            result="SUCCESS",
                            timestamp=datetime.utcnow().isoformat()
                        )]
                    )
                    new_docs.append(doc.dict())

                if new_docs:
                    await self.run_docs.insert_many(new_docs)

        return {"status": "success", "message": "Ingestion completed"}