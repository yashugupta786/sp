"""
Handles SharePoint authentication and file operations using office365-rest-python.
"""

import base64
import io
import re
from office365.sharepoint.client_context import ClientContext
from office365.runtime.auth.client_credential import ClientCredential


class SharePointClient:
    def __init__(self, site_url: str, client_id: str, client_secret: str):
        credentials = ClientCredential(client_id, client_secret)
        self.ctx = ClientContext(site_url).with_credentials(credentials)
        self.site_url = site_url

    def get_folder(self, path: str):
        folder = self.ctx.web.get_folder_by_server_relative_url(path)
        self.ctx.load(folder)
        self.ctx.execute_query()
        return folder

    def get_base64_content(self, file_obj):
        try:
            file_url = file_obj.properties["ServerRelativeUrl"]
            file = self.ctx.web.get_file_by_server_relative_url(file_url)
            mem_file = io.BytesIO()
            file.download(mem_file).execute_query()
            mem_file.seek(0)
            return base64.b64encode(mem_file.read()).decode("utf-8")
        except Exception as e:
            return None

    def extract_year_quarter(self, folder_name: str):
        match = re.match(r"(?i)(Q[1-4])[_\s]?(\d{4})", folder_name.strip())
        if match:
            return match.group(2), match.group(1).upper()
        return None, None