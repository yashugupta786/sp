import yaml
from pymongo import MongoClient

class MongoDBClient:
    """
    Handles MongoDB client creation and database connection
    by reading from a YAML config file.
    """
    def __init__(self, config_path="app/config/settings.yaml"):
        with open(config_path, "r") as f:
            config = yaml.safe_load(f)
        self.mongo_uri = config["mongo_uri"]
        self.db_name = config["database"]

    def get_database(self):
        """Returns the database instance from MongoClient."""
        client = MongoClient(self.mongo_uri)
        return client[self.db_name]
