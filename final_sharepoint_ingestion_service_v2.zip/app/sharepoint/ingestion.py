
import uuid
from datetime import datetime
from app.model.document_schema import DocumentModel, SharePointInfoModel, StepModel

class SharePointIngestionService:
    """
    Handles the core logic to extract metadata and base64 files from SharePoint
    and inserts non-duplicate entries into MongoDB following required schema.
    """
    def __init__(self, db, config):
        self.db = db
        self.site_url = config.get("site_url")
        self.doc_coll = db["run_documents"]
        self.run_coll = db["run_management"]

    async def ingest(self, folder, sp_client, tenant_id, engagement_id, year, quarter):
        try:
            self._load_folders(folder)

            for industry_folder in folder.folders:
                industry = industry_folder.properties["Name"]
                self._load_folders(industry_folder)

                for obligor_folder in industry_folder.folders:
                    obligor = obligor_folder.properties["Name"]
                    doc_run_id = f"{industry}_{quarter}_{year}_{obligor.replace(' ', '_')}"

                    self._load_folders(obligor_folder)
                    all_files = await sp_client.fetch_all_files(obligor_folder)

                    existing_base64s = {
                        doc["base64"]
                        for doc in self.doc_coll.find({"doc_run_id": doc_run_id}, {"base64": 1})
                    }

                    for file_obj in all_files:
                        base64_str = sp_client.get_base64_content(file_obj)
                        if not base64_str or base64_str in existing_base64s:
                            continue

                        doc_id = str(uuid.uuid4())
                        document = DocumentModel(
                            doc_run_id=doc_run_id,
                            run_id=self._get_or_create_run_id(tenant_id, engagement_id),
                            tenant_id=tenant_id,
                            engagement_id=engagement_id,
                            year=int(year),
                            quarter=quarter,
                            industry_type=industry,
                            obligor_name=obligor,
                            doc_id=doc_id,
                            original_filename=file_obj.properties["Name"],
                            base64=base64_str,
                            sharepoint_info=SharePointInfoModel(
                                relative_path=file_obj.properties["ServerRelativeUrl"],
                                library_name="Documents",
                                site_url=self.site_url
                            ),
                            steps=[StepModel(
                                step_name="sharepoint_ingestion",
                                result="SUCCESS",
                                timestamp=datetime.utcnow().isoformat()
                            )]
                        )
                        self.doc_coll.insert_one(document.dict())
                        self._update_run_management(document)

            return {"status": "success", "message": "Ingestion complete"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def _load_folders(self, folder):
        self.db.client.admin.command("ping")  # Simple call to validate Mongo is connected
        folder.context.load(folder.expand(["Folders", "Files"]))
        folder.context.execute_query()

    def _get_or_create_run_id(self, tenant_id, engagement_id):
        existing = self.run_coll.find_one({"tenant_id": tenant_id, "engagement_id": engagement_id})
        if existing:
            return existing["run_id"]
        run_id = f"RUN{str(self.run_coll.estimated_document_count() + 1).zfill(3)}"
        self.run_coll.insert_one({
            "run_id": run_id,
            "tenant_id": tenant_id,
            "engagement_id": engagement_id,
            "metadata": []
        })
        return run_id

    def _update_run_management(self, doc):
        run = self.run_coll.find_one({"run_id": doc.run_id})
        updated = False

        for meta in run["metadata"]:
            if meta["year"] == doc.year and meta["quarter"] == doc.quarter:
                for ind in meta["industries"]:
                    if ind["industry"] == doc.industry_type:
                        if not any(o["obligor_name"] == doc.obligor_name for o in ind["obligors"]):
                            ind["obligors"].append({"obligor_name": doc.obligor_name, "doc_run_id": doc.doc_run_id})
                            updated = True
                        break
                else:
                    meta["industries"].append({
                        "industry": doc.industry_type,
                        "obligors": [{"obligor_name": doc.obligor_name, "doc_run_id": doc.doc_run_id}]
                    })
                    updated = True
                break
        else:
            run["metadata"].append({
                "year": doc.year,
                "quarter": doc.quarter,
                "industries": [{
                    "industry": doc.industry_type,
                    "obligors": [{"obligor_name": doc.obligor_name, "doc_run_id": doc.doc_run_id}]
                }]
            })
            updated = True

        if updated:
            self.run_coll.replace_one({"_id": run["_id"]}, run)
