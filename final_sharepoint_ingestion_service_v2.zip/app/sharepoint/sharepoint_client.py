import base64
import io
import re
from office365.sharepoint.client_context import ClientContext
from office365.runtime.auth.client_credential import ClientCredential

class SharePointClient:
    """SharePoint client to handle authentication and file operations."""
    def __init__(self, site_url: str, client_id: str, client_secret: str):
        credentials = ClientCredential(client_id, client_secret)
        self.ctx = ClientContext(site_url).with_credentials(credentials)
        self.site_url = site_url

    def get_context(self):
        """Returns the initialized SharePoint context."""
        return self.ctx

    def get_folder(self, path: str):
        """Fetches a SharePoint folder by its relative URL."""
        folder = self.ctx.web.get_folder_by_server_relative_url(path)
        self.ctx.load(folder)
        self.ctx.execute_query()
        return folder

    def get_base64_content(self, file_obj):
        """Reads file content from SharePoint and returns base64 string."""
        try:
            file_url = file_obj.properties["ServerRelativeUrl"]
            file = self.ctx.web.get_file_by_server_relative_url(file_url)
            mem_file = io.BytesIO()
            file.download(mem_file).execute_query()
            mem_file.seek(0)
            return base64.b64encode(mem_file.read()).decode("utf-8")
        except Exception as e:
            print(f"[ERROR] Reading file content: {e}")
            return None

    async def fetch_all_files(self, folder):
        """Recursively fetches all files from a SharePoint folder."""
        self.ctx.load(folder.expand(["Folders", "Files"]))
        self.ctx.execute_query()
        all_files = list(folder.files)
        for subfolder in folder.folders:
            all_files.extend(await self.fetch_all_files(subfolder))
        return all_files

    @staticmethod
    def extract_year_quarter(folder_name: str):
        """Extracts year and quarter (e.g., Q1_2025 or Q1 2025)."""
        match = re.match(r"(?i)(Q[1-4])[_\s]?(\d{4})", folder_name.strip())
        if match:
            return match.group(2), match.group(1).upper()
        return None, None
